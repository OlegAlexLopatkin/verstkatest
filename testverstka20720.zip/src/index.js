import './sass/index.sass'
import './js/script.js'